# Grok 6-Bot Trading Team — versao Anatechmg

Equipe de 6 agentes de IA para PESQUISA e VALIDACAO de trades. 100% SIMULACAO:
nenhuma ordem real e enviada. Decisao final exige revisao humana.

## Fluxo
Scout (viabilidade/liquidez) -> News (fatos vs alegacoes) -> Sentiment (humor/hype)
-> Charts (tendencia/suportes/volume) -> RISK (portao: approve/reduce/reject,
regras de risk-rules.json, nunca afrouxa) -> Decision (BUY-SIMULATION-ONLY/WAIT/SKIP).

## Rodar
python3 run_demo.py                 # CAKE (par liquido) ao vivo na BNB Chain
python3 run_demo.py <contract>      # qualquer token BSC
python3 run_demo.py --market data/sample_market.json   # pacote offline

Sem dependencias externas (stdlib pura). Relatorios em reports/, log no proprio
relatorio. Provider mock (heuristico) por padrao; para usar a API do Grok:
export XAI_API_KEY=... e mude "provider" para "grok" no config.json.

## Editar com controle
1. Prompts: prompts/*.txt (mantenha "reply with ONLY valid JSON").
2. Limites de risco: risk-rules.json (escritos por humano; bots apenas leem).
3. Um prompt por vez; compare relatorios antes e depois.

Educacional. Nao e recomendacao de investimento. ANATECHMG LTDA.
