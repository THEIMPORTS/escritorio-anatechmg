#!/usr/bin/env python3
"""Grok 6-Bot Trading Team — versao Anatechmg (BNB Chain real, decisao 100% simulada).

Fluxo: fetch mercado real (DexScreener BSC) -> Scout -> News -> Sentiment -> Charts
       -> RISK (portao) -> Decision -> relatorio JSON + log.

Uso:
  python3 run_demo.py                    # token padrao (CAKE) ao vivo
  python3 run_demo.py <contract>         # qualquer token BSC
  python3 run_demo.py --market data/arquivo.json  # pacote do disco

Provider: mock (heuristico) por padrao; com XAI_API_KEY e provider=grok no
config.json, os prompts vao pra API do Grok. Nenhuma ordem real e enviada.
"""
import json
import os
import sys
import urllib.request
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agents.base import load_config, ValidationError  # noqa: E402
from agents.scout import ScoutBot  # noqa: E402
from agents.news import NewsBot  # noqa: E402
from agents.sentiment import SentimentBot  # noqa: E402
from agents.charts import ChartsBot  # noqa: E402
from agents.risk import RiskBot  # noqa: E402
from agents.decision import DecisionBot  # noqa: E402

DEFAULT_CONTRACT = "0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82"  # CAKE (par liquido de referencia)
DEXS = "https://api.dexscreener.com/latest/dex/tokens/"


def fetch_market(contract):
    """Busca o par mais liquido do token na BSC via DexScreener (fonte publica)."""
    req = urllib.request.Request(DEXS + contract, headers={"User-Agent": "AnatechmgBot/1.0 (pesquisa em simulacao)"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.load(r)
    pairs = [p for p in data.get("pairs") or [] if p.get("chainId") == "bsc"]
    if not pairs:
        raise SystemExit("token nao encontrado na BSC (DexScreener)")
    p = max(pairs, key=lambda x: x.get("liquidity", {}).get("usd") or 0)
    pc = p.get("priceChange") or {}
    tx = (p.get("txns") or {}).get("h24") or {}
    vol = p.get("volume") or {}
    created = p.get("pairCreatedAt")
    return {
        "_label": "DexScreener BSC ao vivo (%s)" % datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "symbol": p.get("baseToken", {}).get("symbol", "?"),
        "nome": p.get("baseToken", {}).get("name", ""),
        "contract": contract,
        "pair": p.get("pairAddress"),
        "quote": p.get("quoteToken", {}).get("symbol"),
        "price_usd": p.get("priceUsd"),
        "liquidity_usd": p.get("liquidity", {}).get("usd"),
        "vol24h_usd": vol.get("h24"),
        "vol_h1": vol.get("h1"),
        "vol_h6": vol.get("h6"),
        "txns_24h": (tx.get("buys") or 0) + (tx.get("sells") or 0),
        "price_change_m5": pc.get("m5"),
        "price_change_h1": pc.get("h1"),
        "price_change_h6": pc.get("h6"),
        "price_change_h24": pc.get("h24"),
        "pool_age_horas": round((datetime.now(timezone.utc).timestamp() * 1000 - created) / 3600000, 1) if created else None,
        "cex_status": "listagem em corretora NAO VERIFICADA neste fluxo",
        "fonte": "DexScreener (publica, sem chave)",
    }


def run(market, config=None, verbose=True):
    config = config or load_config()
    steps = []
    context = {}
    log = []

    pipeline = [
        ("Scout", ScoutBot(config)),
        ("News", NewsBot(config)),
        ("Sentiment", SentimentBot(config)),
        ("Charts", ChartsBot(config)),
    ]
    for name, bot in pipeline:
        out = bot.analyze(market, context)
        context[bot.name] = out
        steps.append((name, out))
        log.extend(bot.log_lines)
        if verbose:
            print("[%d/6] %s Bot complete" % (len(steps), name))

    # ---- RISK: portao obrigatorio; rejeicao interrompe antes do Decision ----
    risk_bot = RiskBot(config)
    risk_out = risk_bot.analyze(market, context)
    context["risk"] = risk_out
    steps.append(("Risk", risk_out))
    log.extend(risk_bot.log_lines)
    if verbose:
        print("[5/6] Risk Bot complete -> %s" % risk_out["status"])

    if risk_out["status"] == "reject":
        decision_out = {
            "decision": "SKIP",
            "reasons": ["Risk rejeitou antes do Decision: " + risk_out["reason"]],
            "conflicting_signals": [],
            "missing_information": [],
            "invalidation_conditions": ["somente reprocessar se as condicoes que geraram a rejeicao mudarem"],
            "human_review_required": True,
        }
        steps.append(("Decision", decision_out))
        log.append("[decision] fluxo interrompido pelo gate de risco")
        if verbose:
            print("[6/6] Risk rejeitou; fluxo interrompido antes do Decision")
    else:
        dec_bot = DecisionBot(config)
        decision_out = dec_bot.analyze(market, context)
        steps.append(("Decision", decision_out))
        log.extend(dec_bot.log_lines)
        if verbose:
            print("[6/6] Decision Bot complete")

    return steps, decision_out, log


def main():
    config = load_config()
    args = sys.argv[1:]
    if args and args[0] == "--market":
        with open(args[1], encoding="utf-8") as f:
            market = json.load(f)
    else:
        contract = args[0] if args else DEFAULT_CONTRACT
        print("Buscando mercado real na BNB Chain (%s)..." % contract)
        market = fetch_market(contract)
        print("Token: %s | liquidez $%s | vol 24h $%s" % (
            market["symbol"], market["liquidity_usd"], market["vol24h_usd"]))

    steps, decision, log = run(market, config)

    print()
    print("Final result: %s" % decision["decision"])
    print("Revisao humana obrigatoria: sim")
    if decision.get("reasons"):
        for r in decision["reasons"][:5]:
            print("  - %s" % r)

    # relatorio
    reports_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), config.get("reports_dir", "reports"))
    os.makedirs(reports_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S-") + os.urandom(3).hex()
    report = {
        "modo": "SIMULATION_ONLY",
        "quando": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "market": market,
        "steps": {name: out for name, out in steps},
        "final": decision,
        "log": log,
    }
    path = os.path.join(reports_dir, "report-%s.json" % ts)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("Report saved -> %s" % path)


if __name__ == "__main__":
    main()
