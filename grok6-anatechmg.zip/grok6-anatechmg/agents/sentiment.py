"""Sentiment: humor/hype a partir de sinais NUMERICOS do pacote (sem rede social conectada)."""
from .base import Agent


def _n(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


class SentimentBot(Agent):
    name = "sentiment"
    schema = {
        "sentiment": ("enum", ["bullish", "mixed", "bearish", "unknown"]),
        "score": ("number",),
        "hype_signals": ("list",),
        "summary": ("string",),
        "confidence": ("number",),
    }

    def mock_analyze(self, market, context=None):
        h1 = _n(market.get("price_change_h1"))
        h6 = _n(market.get("price_change_h6"))
        h24 = _n(market.get("price_change_h24"))
        m5 = _n(market.get("price_change_m5"))
        vr = _n(market.get("volume_ratio_h1_vs_6h_avg"), 1.0)

        hype = []
        if vr >= 3:
            hype.append("volume da ultima hora %.1fx acima da media das 6h (fomo/rotacao possivel)" % vr)
        if h1 >= 15 or m5 >= 10:
            hype.append("repique de curto prazo acentuado (+%.1f%% em 1h / %+.1f%% em 5min)" % (h1, m5))
        if h1 <= -15 or m5 <= -10:
            hype.append("queda brusca de curto prazo (%+.1f%% em 1h)" % h1)

        net = h1 + h6
        if net >= 8:
            sentiment, score = "bullish", 70
        elif net <= -8:
            sentiment, score = "bearish", 30
        elif -8 < net < 8:
            sentiment, score = "mixed", 50
        else:
            sentiment, score = "unknown", 40

        if hype:
            score = min(score, 55)
            summary = "sinais numericos mistos com hype de curto prazo; tratar com desconto"
        else:
            summary = "humor derivado apenas de variacao de preco e volume; sem fonte social conectada"
        return {
            "sentiment": sentiment,
            "score": score,
            "hype_signals": hype,
            "summary": summary,
            "confidence": 45,
        }
