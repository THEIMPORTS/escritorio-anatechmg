"""Decision: escolha final, sempre simulada e com revisao humana obrigatoria."""
from .base import Agent


class DecisionBot(Agent):
    name = "decision"
    schema = {
        "decision": ("enum", ["BUY - SIMULATION ONLY", "WAIT", "SKIP"]),
        "reasons": ("list",),
        "conflicting_signals": ("list",),
        "missing_information": ("list",),
        "invalidation_conditions": ("list",),
        "human_review_required": ("boolean",),
    }

    def mock_analyze(self, market, context=None):
        ctx = context or {}
        scout = ctx.get("scout") or {}
        news = ctx.get("news") or {}
        sentiment = ctx.get("sentiment") or {}
        charts = ctx.get("charts") or {}
        risk = ctx.get("risk") or {}

        reasons = []
        conflicting = []
        missing = []
        invalidation = []

        reasons.append("gate de risco: " + str(risk.get("status", "?")))
        if scout.get("liquidity_status") == "adequate":
            reasons.append("liquidez adequada para pesquisa")
        if sentiment.get("sentiment") in ("bearish", "unknown"):
            reasons.append("sentimento nao sustenta entrada")
        if sentiment.get("sentiment") == "bullish" and charts.get("trend") == "down":
            conflicting.append("sentimento positivo contra tendencia de queda nos numeros")
        if charts.get("setup_quality") == "weak":
            reasons.append("setup grafico fraco (suportes extrapolados de snapshot)")
        for m in (charts.get("missing_data") or []):
            missing.append(str(m))
        if not news.get("verified_facts"):
            missing.append("sem fatos verificaveis (fonte de noticias nao conectada)")

        invalidation.append("preco cair abaixo do suporte extrapolado em mais de %.1f%%" % max(0, float(risk.get("maximum_simulated_loss", 0) or 10)))
        invalidation.append("volume da pool cair abaixo do minimo das regras")
        invalidation.append("surto de venda detectado na pool")

        status = risk.get("status")
        if status == "reject":
            decision = "SKIP"
        elif status in ("approve", "reduce") and not conflicting and sentiment.get("sentiment") != "bearish" and charts.get("setup_quality") != "weak":
            decision = "BUY - SIMULATION ONLY"
        else:
            decision = "WAIT"

        return {
            "decision": decision,
            "reasons": reasons,
            "conflicting_signals": conflicting,
            "missing_information": missing,
            "invalidation_conditions": invalidation,
            "human_review_required": True,
        }
