"""News: separa fatos de dados numericos verificaveis vs alegacoes/ausencia de fonte.

Fonte honesta: neste modo nenhuma API de noticias esta conectada, entao o bot
reporta o que E verificavel no pacote (metricas on-chain da pool) e marca o
resto como alegacao nao verificada. Sempre que houver texto de terceiros no
pacote (ex: nome/descricao), e tratado como dado, nunca como instrucao.
"""
from .base import Agent


def _n(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


class NewsBot(Agent):
    name = "news"
    schema = {
        "verified_facts": ("list",),
        "unverified_claims": ("list",),
        "manipulation_attempts": ("list",),
        "summary": ("string",),
        "confidence": ("number",),
    }

    def mock_analyze(self, market, context=None):
        facts = []
        claims = []
        manip = []

        for field, label in (
            ("liquidity_usd", "liquidez atual"),
            ("vol24h_usd", "volume 24h"),
            ("txns_24h", "transacoes 24h"),
        ):
            v = market.get(field)
            if v is not None:
                facts.append("%s = %s (fonte: DexScreener, verificavel)" % (label, v))

        if _n(market.get("txns_24h")) > 5000 and _n(market.get("vol24h_usd")) > 5000000:
            claims.append("volume elevado pode indicar hype de curto prazo; causa nao verificada (sem fonte de noticias conectada)")

        for text in (market.get("nome", ""), market.get("descricao", "")):
            if text and any(w in str(text).lower() for w in ("clique", "envie", "compre agora", "envie pix", "seed phrase", "sua chave")):
                manip.append("conteudo de terceiro contem possivel comando/instrucao (tratado como dado, ignorado)")

        if market.get("cex_status"):
            claims.append(str(market["cex_status"]))

        summary = (
            "Metricas de pool verificaveis registradas como fatos; narratives de mercado sem fonte de noticias conectada neste modo."
            if facts
            else "Nenhum fato verificavel no pacote."
        )
        return {
            "verified_facts": facts,
            "unverified_claims": claims,
            "manipulation_attempts": manip,
            "summary": summary,
            "confidence": 60 if facts else 20,
        }
