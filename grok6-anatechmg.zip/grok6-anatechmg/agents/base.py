"""Base: carrega prompts, provider (mock deterministico ou Grok) e validacao JSON com 1 retry."""
import json
import os
import re
import urllib.request

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPTS_DIR = os.path.join(BASE_DIR, "prompts")


def load_prompt(name):
    with open(os.path.join(PROMPTS_DIR, name + ".txt"), encoding="utf-8") as f:
        return f.read()


def load_config():
    with open(os.path.join(BASE_DIR, "config.json"), encoding="utf-8") as f:
        return json.load(f)


def load_risk_rules():
    with open(os.path.join(BASE_DIR, "risk-rules.json"), encoding="utf-8") as f:
        return json.load(f)


class ValidationError(Exception):
    pass


def validate(schema, obj):
    """Valida conjunto de chaves, tipos e valores permitidos. Raises ValidationError."""
    if not isinstance(obj, dict):
        raise ValidationError("saida nao e objeto JSON")
    for key, spec in schema.items():
        if key not in obj:
            raise ValidationError("campo ausente: " + key)
        val = obj[key]
        kind = spec[0]
        if kind == "enum" and val not in spec[1]:
            raise ValidationError("valor fora da lista em %s: %r" % (key, val))
        if kind == "string" and not isinstance(val, str):
            raise ValidationError("tipo errado em %s (esperado string)" % key)
        if kind == "number" and not isinstance(val, (int, float)):
            raise ValidationError("tipo errado em %s (esperado numero)" % key)
        if kind == "list" and not isinstance(val, list):
            raise ValidationError("tipo errado em %s (esperado lista)" % key)
        if kind == "list_of_numbers" and (not isinstance(val, list) or any(not isinstance(x, (int, float)) for x in val)):
            raise ValidationError("tipo errado em %s (esperado lista de numeros)" % key)
        if kind == "boolean" and not isinstance(val, bool):
            raise ValidationError("tipo errado em %s (esperado booleano)" % key)


def extract_json(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValidationError("nenhum objeto JSON encontrado na resposta")
    return json.loads(m.group(0))


def call_grok(prompt, system, config):
    """Chama a API do Grok (OpenAI-compatible). Requer XAI_API_KEY e provider=grok no config."""
    api_key = os.environ.get("XAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("XAI_API_KEY ausente no ambiente")
    body = json.dumps({
        "model": config.get("model", "grok-4.7"),
        "temperature": config.get("temperature", 0.2),
        "max_tokens": config.get("max_output_tokens", 1024),
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
    }).encode()
    req = urllib.request.Request(
        config.get("api_base", "https://api.x.ai/v1").rstrip("/") + "/chat/completions",
        data=body,
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + api_key},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.load(r)
    return data["choices"][0]["message"]["content"]


class Agent:
    """Um dos seis bots. analyze() roda o provider com validacao e 1 retry."""

    name = "base"
    schema = {}

    def __init__(self, config=None):
        self.config = config or load_config()
        self.log_lines = []

    def market_package_text(self, market, context=None):
        return json.dumps({"market": market, "context": context or {}}, ensure_ascii=False)

    def mock_analyze(self, market, context=None):
        raise NotImplementedError

    def analyze(self, market, context=None):
        self.log_lines = []
        provider = self.config.get("provider", "mock")
        attempts = 0
        last_err = None
        while attempts < 2:
            attempts += 1
            try:
                if provider == "grok":
                    raw = call_grok(
                        self.market_package_text(market, context),
                        load_prompt(self.name),
                        self.config,
                    )
                    out = extract_json(raw)
                else:
                    out = self.mock_analyze(market, context)
                validate(self.schema, out)
                self.log_lines.append("[%s] ok (tentativa %d)" % (self.name, attempts))
                return out
            except (ValidationError, ValueError, KeyError) as e:
                last_err = str(e)
                self.log_lines.append("[%s] saida invalida: %s" % (self.name, last_err))
        raise ValidationError("%s: JSON invalido apos retry: %s" % (self.name, last_err))
