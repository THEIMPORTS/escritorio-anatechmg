"""Camadas de debate (arquitetura TradingAgents — TauricResearch, arXiv 2412.20138).

Antes do Decision, quando o Risk nao rejeita:
  1. TORO (bull researcher) argumenta a favor da entrada simulada;
  2. URSO (bear researcher) refuta com os riscos reais dos numeros;
  3. JUIZ (research manager) julga o debate (vencedor + confianca);
  4. TRIO DE RISCO (agressivo/conservador/neutro) define o tamanho ideal em USD.

Debates ENRIQUECEM a decisao; as regras duras do Risk continuam mandando.
Tudo em SIMULACAO, sem ordem real e sem promessa de rendimento.
"""
from .base import Agent


class TouroBot(Agent):
    name = "touro"
    schema = {
        "argument": ("string",),
        "strength": ("number",),
    }

    def mock_analyze(self, market, context=None):
        ctx = context or {}
        risk = ctx.get("risk") or {}
        sentiment = ctx.get("sentiment") or {}
        charts = ctx.get("charts") or {}
        args = []
        liq = float(market.get("liquidity_usd") or 0)
        vol = float(market.get("vol24h_usd") or 0)
        if liq >= 100000:
            args.append("liquidez de $%d sustenta execucao" % liq)
        if vol >= 300000:
            args.append("volume 24h de $%d indica fluxo real" % vol)
        lp = float(market.get("lp_locked_pct") or 0)
        if lp >= 90:
            args.append("LP %.1f%% queimado reduz risco de rug" % lp)
        if sentiment.get("sentiment") == "bullish":
            args.append("sentimento de mercado construtivo")
        if charts.get("trend") == "up":
            args.append("tendencia de alta nos numeros")
        if not args:
            args.append("score do scanner aprovou; perfil adequado para entrada simulada")
        strength = 6.0 if risk.get("status") == "approve" else 4.0
        return {"argument": "; ".join(args[:3]) + ".", "strength": strength}


class UrsoBot(Agent):
    name = "urso"
    schema = {
        "argument": ("string",),
        "strength": ("number",),
    }

    def mock_analyze(self, market, context=None):
        ctx = context or {}
        risk = ctx.get("risk") or {}
        sentiment = ctx.get("sentiment") or {}
        charts = ctx.get("charts") or {}
        args = []
        h1 = float(market.get("price_change_h1_pct") or 0)
        h6 = float(market.get("price_change_h6_pct") or 0)
        if h1 <= -10 or h6 <= -10:
            args.append("queda de %.1f%% em 1h e %.1f%% em 6h mostra pressao vendedora" % (h1, h6))
        if sentiment.get("sentiment") == "bearish":
            args.append("sentimento baixista confirmado")
        if charts.get("trend") == "down":
            args.append("tendencia de queda")
        if charts.get("setup_quality") == "weak":
            args.append("setup grafico fraco (suportes extrapolados de snapshot)")
        age = float(market.get("pool_age_hours") or 0)
        if age and age < 48:
            args.append("pool com apenas %.1fh de historia" % age)
        if not args:
            args.append("ativo novo, historico insuficiente para tese confiavel")
        strength = 7.0 if risk.get("status") == "reduce" else 5.0
        return {"argument": "; ".join(args[:3]) + ".", "strength": strength}


class JuizBot(Agent):
    name = "juiz"
    schema = {
        "vencedor": ("enum", ["touro", "urso", "empate"]),
        "confianca": ("number",),
        "resumo": ("string",),
    }

    def mock_analyze(self, market, context=None):
        ctx = context or {}
        touro = ctx.get("touro") or {}
        urso = ctx.get("urso") or {}
        s_t = float(touro.get("strength") or 0)
        s_u = float(urso.get("strength") or 0)
        if s_u > s_t + 0.5:
            vencedor, conf = "urso", min(95, 55 + (s_u - s_t) * 10)
        elif s_t > s_u + 0.5:
            vencedor, conf = "touro", min(95, 55 + (s_t - s_u) * 10)
        else:
            vencedor, conf = "empate", 50
        resumo = ("urso: " + str(urso.get("argument", ""))[:60]) if vencedor == "urso" else (
            ("touro: " + str(touro.get("argument", ""))[:60]) if vencedor == "touro" else "argumentos equilibrados"
        )
        return {"vencedor": vencedor, "confianca": round(conf), "resumo": resumo}


class TrioRiscoBot(Agent):
    """Tres gestores de risco (AGRESSIVO, CONSERVADOR, NEUTRO) definem o tamanho
    ideal da posicao SIMULADA em USD. O conservador nunca sugere mais que o agressivo."""
    name = "trio_risco"
    schema = {
        "agressivo_usd": ("number",),
        "agressivo_arg": ("string",),
        "conservador_usd": ("number",),
        "conservador_arg": ("string",),
        "neutro_usd": ("number",),
        "neutro_arg": ("string",),
    }

    def mock_analyze(self, market, context=None):
        ctx = context or {}
        risk = ctx.get("risk") or {}
        maximo = float(risk.get("max_simulated_position_usd") or 10)
        sentiment = ctx.get("sentiment") or {}
        cons_mult = 0.25 if sentiment.get("sentiment") == "bearish" else 0.4
        agressivo = round(maximo * 0.5, 2)
        conservador = round(maximo * cons_mult, 2)
        neutro = round((agressivo + conservador) / 2, 2)
        return {
            "agressivo_usd": agressivo,
            "agressivo_arg": "score aprovado; risco aceito dentro do limite",
            "conservador_usd": conservador,
            "conservador_arg": "exposicao minima ate confirmacao da tese",
            "neutro_usd": neutro,
            "neutro_arg": "equilibrio entre potencial e volatilidade recente",
        }


def tamanho_sugerido(juiz, trio, maximo):
    """Mediana do trio limitada pelo Risk; juiz urso convicto zera a posicao."""
    if juiz.get("vencedor") == "urso" and float(juiz.get("confianca") or 0) >= 60:
        return 0.0
    valores = [v for v in (trio.get("agressivo_usd"), trio.get("conservador_usd"), trio.get("neutro_usd")) if isinstance(v, (int, float)) and v > 0]
    if not valores:
        return float(maximo or 0)
    valores.sort()
    mediana = valores[len(valores) // 2]
    return round(min(float(maximo or mediana), mediana), 2)
