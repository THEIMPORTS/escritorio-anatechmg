"""Charts: leitura numerica de tendencia, suportes/resistencias e volume.

Trabalha com o que o pacote traz (snapshot DexScreener). Sem candles historicos,
extrapola suporte/resistencia a partir do preco atual e das variacoes — e
registra explicitamente o que falta.
"""
from .base import Agent


def _n(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


class ChartsBot(Agent):
    name = "charts"
    schema = {
        "trend": ("enum", ["up", "sideways", "down", "unknown"]),
        "support_levels": ("list_of_numbers",),
        "resistance_levels": ("list_of_numbers",),
        "volume_summary": ("string",),
        "setup_quality": ("enum", ["strong", "moderate", "weak"]),
        "missing_data": ("list",),
        "confidence": ("number",),
    }

    def mock_analyze(self, market, context=None):
        p = _n(market.get("price_usd"))
        h1 = _n(market.get("price_change_h1"))
        h6 = _n(market.get("price_change_h6"))
        h24 = _n(market.get("price_change_h24"))
        vr = _n(market.get("volume_ratio_h1_vs_6h_avg"), 1.0)
        txns = _n(market.get("txns_24h"))

        if p <= 0:
            return {
                "trend": "unknown",
                "support_levels": [],
                "resistance_levels": [],
                "volume_summary": "sem preco no pacote",
                "setup_quality": "weak",
                "missing_data": ["price_usd"],
                "confidence": 10,
            }

        net = h1 + h6
        if net >= 5:
            trend = "up"
        elif net <= -5:
            trend = "down"
        else:
            trend = "sideways"

        # extrapolacao honesta: faixa derivada das variacoes, rotulada como aproximada
        support = round(p * (1 + min(h1, h6, 0) / 100), 8)
        resistance = round(p * (1 + max(h1, h6, 0) / 100), 8)

        missing = ["candles intradiarios (suportes/resistencias extrapolados do snapshot)"]
        if not market.get("volume_ratio_h1_vs_6h_avg"):
            missing.append("volume relativo calculado fora do pacote")

        quality = "moderate" if (trend in ("up", "sideways") and vr >= 1.5) else "weak"

        return {
            "trend": trend,
            "support_levels": [support],
            "resistance_levels": [resistance],
            "volume_summary": "volume 1h %.1fx a media 6h; %d transacoes em 24h" % (vr, int(txns)),
            "setup_quality": quality,
            "missing_data": missing,
            "confidence": 40,
        }
