"""Scout: triagem de mercado — liquidez, transacoes, idade da pool, qualidade dos dados."""
from .base import Agent


def _n(v, default=0.0):
    try:
        x = float(v)
        return x
    except (TypeError, ValueError):
        return default


class ScoutBot(Agent):
    name = "scout"
    schema = {
        "market": ("string",),
        "reason_to_research": ("string",),
        "liquidity_status": ("enum", ["adequate", "thin", "insufficient", "unknown"]),
        "data_quality": ("enum", ["good", "partial", "poor"]),
        "confidence": ("number",),
    }

    def mock_analyze(self, market, context=None):
        liq = _n(market.get("liquidity_usd"))
        vol24 = _n(market.get("vol24h_usd"))
        txns = _n(market.get("txns_24h"))
        age_h = _n(market.get("pool_age_horas"), -1)

        if liq >= 100000 and vol24 >= 200000:
            liquidity_status = "adequate"
        elif liq >= 50000:
            liquidity_status = "thin"
        else:
            liquidity_status = "insufficient"

        missing = []
        for field in ("price_usd", "liquidity_usd", "vol24h_usd", "txns_24h"):
            if market.get(field) is None:
                missing.append(field)
        data_quality = "good" if not missing else ("partial" if len(missing) == 1 else "poor")

        if liquidity_status == "insufficient":
            reason = "liquidez abaixo do minimo de triagem"
        elif age_h >= 0 and age_h < 2:
            reason = "pool muito nova; dado de mercado instavel"
        elif liq > 0:
            reason = "liquidez e volume permitem pesquisa sem mover o preco"
        else:
            reason = "sem dado de liquidez"

        confidence = 70 if data_quality == "good" else (45 if data_quality == "partial" else 20)
        return {
            "market": str(market.get("symbol", "?")),
            "reason_to_research": reason,
            "liquidity_status": liquidity_status,
            "data_quality": data_quality,
            "confidence": confidence,
        }
