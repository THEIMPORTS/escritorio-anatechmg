"""Risk: portao obrigatorio. Aplica risk-rules.json — so limita, nunca afrouxa."""
from .base import Agent, load_risk_rules


def _n(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


class RiskBot(Agent):
    name = "risk"
    schema = {
        "status": ("enum", ["approve", "reduce", "reject"]),
        "maximum_simulated_size": ("number",),
        "maximum_simulated_loss": ("number",),
        "risk_flags": ("list",),
        "reason": ("string",),
    }

    def mock_analyze(self, market, context=None):
        rules = load_risk_rules()
        liq = _n(market.get("liquidity_usd"))
        vol24 = _n(market.get("vol24h_usd"))
        txns = _n(market.get("txns_24h"))
        age_h = _n(market.get("pool_age_horas"), -1)
        h1 = _n(market.get("price_change_h1"))
        h24 = _n(market.get("price_change_h24"))
        size_max = _n(rules.get("tamanho_simulado_max_usd"), 10)
        loss_max_pct = _n(rules.get("perda_simulada_max_pct"), 10)

        flags = []

        if liq < _n(rules.get("liquidez_min_usd"), 50000):
            flags.append("liquidez_insuficiente")
        if vol24 < _n(rules.get("vol24h_min_usd"), 100000):
            flags.append("volume_24h_baixo")
        if txns < _n(rules.get("txns_24h_min"), 100):
            flags.append("poucas_transacoes")
        if 0 <= age_h < 2:
            flags.append("pool_muito_nova")
        if age_h < 0:
            flags.append("dados_ausentes_criticos")
        if h1 <= _n(rules.get("queda_1h_max_pct"), -15):
            flags.append("queda_repiquinho")
        if abs(h24) >= _n(rules.get("variacao_24h_max_abs_pct"), 60):
            flags.append("variacao_24h_extrema")

        # contexto dos bots de pesquisa influencia: achismos/hype => reducao
        scout = (context or {}).get("scout") or {}
        news = (context or {}).get("news") or {}
        sentiment = (context or {}).get("sentiment") or {}
        charts = (context or {}).get("charts") or {}

        if scout.get("liquidity_status") == "insufficient":
            flags.append("liquidez_insuficiente")
        if scout.get("data_quality") == "poor":
            flags.append("dados_ausentes_criticos")
        if charts.get("setup_quality") == "weak":
            flags.append("setup_fraco")
        if sentiment.get("sentiment") == "bearish":
            flags.append("sentimento_baixista")
        if news.get("unverified_claims") and not news.get("verified_facts"):
            flags.append("sem_fatos_verificaveis")

        hard = set(rules.get("flags_obrigatoria_rejeicao", []))
        if hard & set(flags):
            status, size = "reject", 0
            reason = "regra obrigatoria violada: " + ", ".join(sorted(hard & set(flags)))
        elif flags:
            status, size = "reduce", round(size_max / 2, 2)
            reason = "sinais de atencao: " + ", ".join(flags[:4])
        else:
            status, size = "approve", size_max
            reason = "todas as regras de risco respeitadas"

        return {
            "status": status,
            "maximum_simulated_size": size,
            "maximum_simulated_loss": round(size * loss_max_pct / 100, 2),
            "risk_flags": sorted(set(flags)),
            "reason": reason,
        }
